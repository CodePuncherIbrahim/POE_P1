﻿using System;
namespace POE_P1
{
	public class Recipe
	{
        // attributes
        public string name;
        private int numberOfIngredients;
        private string category;
		private int numberOfSteps;
        public List<String> steps = new List<String>();
        public List<Ingredient> ingredients = new List<Ingredient>();


		// constructor not used
        public Recipe() {}

		// set methods
		public void SetName(string name) { this.name = name; }
        public void SetNumberOfIngredients(int numberOfIngredients) { this.numberOfIngredients = numberOfIngredients; }
        public void SetCategory(string category) { this.category = category; }
        public void SetNumberOfSteps(int steps) { this.numberOfSteps = steps; }

        // get methods
        public string GetName() { return name; }
        public int GetNumberOfIngredients() { return numberOfIngredients; }
        public string GetCategory() { return category; }
        public int GetNumberOfSteps() { return numberOfSteps; }

        // 1) methods
        public Recipe CreateRecipe()
        {
            // recipe object created
            Recipe recipe = new();

            // gets recipe name
            Console.Write("Enter Recipe Name: ");
            recipe.SetName(Console.ReadLine());

            // gets category
            Console.WriteLine("\nChoose Category: \n1). Appetizer \n2). Salad \n3). Main-course \n4). Dessert \n5). Baked-goods \n6). Soup");
            string userOption1 = Console.ReadLine();
            int pick1 = Int32.Parse(userOption1);

            // conditional switch cases
            switch (pick1)
            {
                case 1:
                    recipe.SetCategory("Appetizer");
                    break;
                case 2:
                    recipe.SetCategory("Salad");
                    break;
                case 3:
                    recipe.SetCategory("Main-course");
                    break;
                case 4:
                    recipe.SetCategory("Dessert");
                    break;
                case 5:
                    recipe.SetCategory("Baked-goods");
                    break;
                case 6:
                    recipe.SetCategory("Soup");
                    break;
                default:
                    Console.WriteLine("Choose Valid Option.");
                    break;
            }

            // gets ingredient number
            Console.Write("\nEnter Number Of Ingredients: ");
            string num1 = Console.ReadLine();
            numberOfIngredients = Int32.Parse(num1); // turns string into integer
            recipe.SetNumberOfIngredients(numberOfIngredients);

            // gets number of steps
            Console.Write("\nEnter Number Of Steps: ");
            string num2 = Console.ReadLine();
            numberOfSteps = Int32.Parse(num2); // turns string into integer
            recipe.SetNumberOfSteps(numberOfSteps);

            return recipe;

        }


        // method to add ingredient
        public void AddIngredient()
        {
            int count = 1; // keeps count of items added

            // ingredient is added
            for (int i = 0; i < numberOfIngredients; i++)
            {

                Ingredient ingredient = new Ingredient(); //object

                Console.Write("\nIngredient " + count + " - Enter Name: ");
                ingredient.SetName(Console.ReadLine());

                Console.WriteLine("\nQuantity? (Numeric Value)");
                String num = (Console.ReadLine());
                ingredient.SetQuantity(Double.Parse(num));

                Console.WriteLine("\nUnits Of Measurements: \n1). grams \n2). ml \n3). teaspoon \n4). tablespoon \n5). cup");
                string userOption2 = Console.ReadLine();
                int pick2 = Int32.Parse(userOption2);


                // conditional switch cases
                switch (pick2)
                {
                    case 1:
                        ingredient.SetUnits("gram(s)");
                        break;
                    case 2:
                        ingredient.SetUnits("ml(s)");
                        break;
                    case 3:
                        ingredient.SetUnits("teaspoon(s)");
                        break;
                    case 4:
                        ingredient.SetUnits("tablespoon(s)");
                        break;
                    case 5:
                        ingredient.SetUnits("cup(s)");
                        break;
                    default:
                        Console.WriteLine("Choose Valid Option.");
                        break;
                }

                Console.WriteLine("\nIngredient Added!");

                ingredients.Add(ingredient);

                count++;
            }
           
        }


        // method to add step
        public void AddStep()
        {
            int count = 1; // keeps count of items added

            for (int i = 0; i < numberOfSteps; i++)
            {
                Console.WriteLine("\nStep " + count);
                //steps.Add(Console.ReadLine());
                // list.Add(Console.ReadLine());
                steps.Add(Console.ReadLine());

                count++;
            }
        }


        // 2) methods
        public void DisplayRecipe(Recipe recipe)
        {
            Console.WriteLine("\n\n=========================================================");
            Console.WriteLine("Recipe Name: \t\t\t\t" + recipe.GetName().ToUpper());
            Console.WriteLine("Category: \t\t\t\t" + recipe.GetCategory().ToUpper());
            Console.WriteLine("Number of Ingredients: \t\t\t" + recipe.GetNumberOfIngredients());
            Console.WriteLine("Number of Steps: \t\t\t" + recipe.GetNumberOfSteps());

            Console.WriteLine("\nINGREDIENTS: ");
            Console.WriteLine("- - - - - - - - - - - - - - - - - - - - - - - - - - - - -");
            

            // loop
            ingredients.ToString();
            PrintIngredients(ingredients);

            Console.WriteLine("\nSTEPS: ");
            Console.WriteLine("- - - - - - - - - - - - - - - - - - - - - - - - - - - - -");

            // loop
            steps.ToString();
            PrintSteps(steps);

            Console.WriteLine("\n=========================================================");

        } 


        // print methods
        public void PrintIngredients(List<Ingredient> list)
        {
            foreach (Ingredient item in list)
            {
                int count = 1;

                Console.WriteLine(item.GetQuantity() + " " + item.GetUnits() + " of " + item.GetName());

                count++;
            }
        }

        public void PrintSteps(List<String> list)
        {
            int count = 1; // keeps count

            foreach (String step in list)
            {

                Console.WriteLine(count + ". " + step);

                count++;
            }
        }


        // manipulate recipe methods
        public void ScaleRecipe()
        {
            Console.WriteLine("\nDo you wish to scale your recipe " + name.ToUpper() + "? 1 For 'YES' 0 For 'NO'");
            string pick = Console.ReadLine();
            int num = Int32.Parse(pick);

            // conditions
            if (num == 1)
            {
                Console.WriteLine("\nScale by: \n1) 0.5 (Half) \n2) 2 (Double) \n3) (Triple)");
                string pick2 = Console.ReadLine();
                int num2 = Int32.Parse(pick2);


                // switch
                switch (num2)
                {
                    case 1:
                        Divide();
                        break;
                    case 2:
                        MultiplyTwice();
                        break;
                    case 3:
                        MultiplyTrice();
                        break;
                    default:
                        Console.WriteLine("Invalid Choice.");
                        break;
                }   
                
            }
            else if (num == 0)
            {
                Console.WriteLine("\nQuantities remain unchanged.");
            }
            else Console.WriteLine("\nInvalid Choice");
        }

        // maths methods
        public void Divide()
        {
            Console.WriteLine("\nNew Quantities:".ToUpper());
            Console.WriteLine("- - - - - - - - - - - - - - - - - - - - - - - - - - - - -");

            foreach (Ingredient item in ingredients)
            {
                double answer = item.GetQuantity() / 0.5;
                Console.WriteLine(answer + " " + item.GetUnits() + " of " + item.GetName()); // print the value but doen't change the original
            }

        }
        public void MultiplyTwice()
        {
            
            Console.WriteLine("\nNew Quantities:".ToUpper());
            Console.WriteLine("- - - - - - - - - - - - - - - - - - - - - - - - - - - - -");

            foreach (Ingredient item in ingredients)
            {
                double answer = item.GetQuantity() * 2;
                Console.WriteLine(answer + " " + item.GetUnits() + " of " + item.GetName());
            }

        }
        public void MultiplyTrice()
        {
            Console.WriteLine("\nNew Quantities:".ToUpper());
            Console.WriteLine("- - - - - - - - - - - - - - - - - - - - - - - - - - - - -");

            foreach (Ingredient item in ingredients)
            {
                double answer = item.GetQuantity() * 3;
                Console.WriteLine(answer + " " + item.GetUnits() + " of " + item.GetName());
            }
        }

        // reset values
        public void ResetValues()
        {
            Console.WriteLine("\nDo you wish to reset the values? 1 For 'YES' 0 For 'NO'");
            int pick = Int32.Parse(Console.ReadLine());

            switch (pick)
            {
                case 1:
                    Console.WriteLine("\n");
                    PrintIngredients(ingredients);
                    break;
                case 0:
                    Console.WriteLine("\nValues Remain Unchanged.");
                    break;
                default:
                    Console.WriteLine("\nInvalid Choice.");
                    break;
            }
        }

    }
}

