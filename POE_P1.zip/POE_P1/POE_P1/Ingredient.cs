﻿using System;
namespace POE_P1
{
	public class Ingredient
	{
		//attributes
		public string name;
		public double quantity;
		public string unitOfMeasurement;

        /*
		// constructor
		public Ingredient(string name, double quantity, string unitOfMeasurement)
		{
			this.name = name;
			this.quantity = quantity;
			this.unitOfMeasurement = unitOfMeasurement;
		}
        */

        
        // set methods
        public void SetName(string name)
        {
            this.name = name;
        }
        public void SetQuantity(double quantity)
        {
            this.quantity = quantity;
        }
        public void SetUnits(string units)
        {
            this.unitOfMeasurement = units;
        }

        // get methods
        public string GetName()
        {
            return name;
        }
        public double GetQuantity()
        {
            return quantity;
        }
        public string GetUnits()
        {
            return unitOfMeasurement;
        }


        public void print(List<Ingredient> list)
        {
            Console.WriteLine();
        }


    }
}

